import time
import requests
import grovepi
import sys

dht11_port = 8                           # DHT22 temp & humidity sensor is connected to port D8
url = "http://10.10.88.246:3000/dht"

while True:
  
  try:

    # Read the temperature and humidity

    [temp, humi] = grovepi.dht(dht11_port, 0)               # second parameter:  0 = DHT22 sensor

    print(temp, "C")
    print(humi, "%")

    payload = { 'h' : humi, 't' : temp }

    requests.post(url, data=payload)    # write data

    time.sleep(2.0)           # 2 second delay

  except KeyboardInterrupt:
    print "Terminating"
    break
  except IOError:
    print "IOError, continuing"
  except:
    print "Unexpected error, continuing"
    print "sys.exc_info()[0]: ", sys.exc_info()[0]

